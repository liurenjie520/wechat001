#! usr/bin/env python
# -*- coding: utf-8 -*-
# Date: 2019/6/23
# Author: snow

script_name = 'EverydayWechat'
__author__ = 'sfyc23'
__license__ = 'MIT'
__version__ = '0.3.27'

