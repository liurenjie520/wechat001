# coding=utf-8
"""
从土味情话中获取每日一句。
 """
import requests
import json



__all__ = ['get_bilibili_info']


def get_bilibili_info():

    print('获取...')
    try:
        resp = requests.get('https://api.bilibili.com/x/web-interface/ranking/v2?rid=188&type=all')
        if resp.status_code == 200:
            content_dict = resp.json()


            data = content_dict.get("data").get("list")
            result1 = []
            srt22=""
            for i in data:
                result1.append(i.get("title"))

            for player in result1[:8]:
                print(player.title())

            # for i in result1:
            #
            #
            #  print(result1.index(i) + 1, i)



            return srt22

        print('获取失败。')
    except requests.exceptions.RequestException as exception:
        print(exception)
        # return None
    return None




if __name__ == '__main__':

    is_tomorrow =  get_bilibili_info()
    print(is_tomorrow)