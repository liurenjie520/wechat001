# coding=utf-8
"""
从土味情话中获取每日一句。
 """
import requests
import json


__all__ = ['get_lovelive_info']


def get_lovelive_info():

    print('获取...')
    try:
        resp = requests.get('https://tenapi.cn/comment/')
        if resp.status_code == 200:
            content_dict = resp.json()


            data1 = content_dict.get("data").get("content")
            data2 = content_dict.get("data").get("song") #gequ
            data3 = content_dict.get("data").get("sing")

            # result1 = []
            # for i in data:
            print(data1+"\n《"+data2+"》\n"+"--"+data3)

            return ""
        print('获取失败。')
    except requests.exceptions.RequestException as exception:
        print(exception)
        # return None
    return None


get_one_words = get_lovelive_info

if __name__ == '__main__':

    is_tomorrow =  get_lovelive_info()
    print(is_tomorrow)