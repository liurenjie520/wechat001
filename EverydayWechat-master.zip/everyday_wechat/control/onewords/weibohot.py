# coding=utf-8
"""
从土味情话中获取每日一句。
 """
import requests
import json


__all__ = ['get_lovelive_info']


def get_lovelive_info():

    print('获取...')
    try:
        resp = requests.get('https://tenapi.cn/resou/')
        if resp.status_code == 200:
            content_dict = resp.json()


            data = content_dict.get("list")
            result1 = []
            for i in data:
                result1.append(i.get("name")+">>>"+i.get("url"))




            for i in result1:

                print(result1.index(i) + 1,i)


            return ""
        print('获取失败。')
    except requests.exceptions.RequestException as exception:
        print(exception)
        # return None
    return None


get_one_words = get_lovelive_info

if __name__ == '__main__':

    is_tomorrow =  get_lovelive_info()
    print(is_tomorrow)